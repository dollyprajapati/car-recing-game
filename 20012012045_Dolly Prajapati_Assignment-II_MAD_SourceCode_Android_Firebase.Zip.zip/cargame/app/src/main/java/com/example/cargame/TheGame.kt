package com.example.cargame

import com.example.cargame.GameView
import com.example.cargame.GameThread
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.example.cargame.R

class TheGame(gameView: GameView) : GameThread(gameView) {
    //Will store the image of a ball
    private val mBall: Bitmap
    private val mBall2: Bitmap

    //The X and Y position of the ball on the screen (middle of ball)
    private var mBallX = 0f
    private var mBallY = 0f
    private var mBallX2 = 0f
    private var mBallY2 = 0f

    //The speed (pixel/second) of the ball in direction X and Y
    private var mBallSpeedX = 0f
    private var mBallSpeedY = 0f
    private var mBallSpeedX2 = 0f
    private var mBallSpeedY2 = 0f

    //This is run before a new game (also after an old game)
    override fun setupBeginning() {
        //Initialise speeds
        mBallSpeedX = 100f
        mBallSpeedY = 100f
        mBallSpeedX2 = -90f
        mBallSpeedY2 = -90f
        //Place the ball in the middle of the screen.
        //mBall.Width() and mBall.getHeigh() gives us the height and width of the image of the ball
        mBallX = (mCanvasWidth / 2).toFloat()
        mBallY = (mCanvasHeight / 2).toFloat()
        mBallX2 = (mCanvasWidth / 2).toFloat()
        mBallY2 = (mCanvasHeight / 2).toFloat()
    }

    override fun actionOnTouch(x: Float, y: Float) {
        //Increase/decrease the speed of the ball making the ball move towards the touch
        mBallSpeedX = x - mBallX
        mBallSpeedY = y - mBallY
    }

    //This is run whenever the phone moves around its axises 
    override fun actionWhenPhoneMoved(xDirection: Float, yDirection: Float, zDirection: Float) {

        /*Increase/decrease the speed of the ball.
		If the ball moves too fast try and decrease 70f
		If the ball moves too slow try and increase 70f */
        mBallSpeedX = mBallSpeedX + 70f * xDirection
        mBallSpeedY = mBallSpeedY - 70f * yDirection
        mBallSpeedX2 = mBallSpeedX2 + 70f * xDirection
        mBallSpeedY2 = mBallSpeedY2 - 70f * yDirection
    }

    //This is run just before the game "scenario" is printed on the screen
    override fun updateGame(secondsElapsed: Float) {
        if (mBallX > mCanvasWidth || mBallX < 0) {
            mBallSpeedX = -mBallSpeedX
        }
        if (mBallY > mCanvasHeight || mBallY < 0) {
            mBallSpeedY = -mBallSpeedY
        }
        if (mBallX2 > mCanvasWidth || mBallX2 < 0) {
            mBallSpeedX2 = -mBallSpeedX2
        }
        if (mBallY2 > mCanvasHeight || mBallY2 < 0) {
            mBallSpeedY2 = -mBallSpeedY2
        }
        //Move the ball's X and Y using the speed (pixel/sec)
        mBallX = mBallX + secondsElapsed * mBallSpeedX
        mBallY = mBallY + secondsElapsed * mBallSpeedY
        mBallX2 = mBallX2 + secondsElapsed * mBallSpeedX2
        mBallY2 = mBallY2 + secondsElapsed * mBallSpeedY2
    }

    //This is run before anything else, so we can prepare things here
    init {
        //House keeping

        //Prepare the image so we can draw it on the screen (using a canvas)
        mBall = BitmapFactory.decodeResource(
            gameView.context.resources,
            R.drawable.car1
        )
        mBall2 = BitmapFactory.decodeResource(
            gameView.context.resources,
            R.drawable.car2
        )
    }
}