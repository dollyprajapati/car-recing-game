package com.example.cargame

import kotlin.jvm.JvmStatic
import com.example.cargame.SimpleHTTPServer2
import java.io.*
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.*

object SimpleHTTPServer2 {
    private const val RELPATH = "serverFiles"
    fun getFile(f: File?): ByteArray? {
        val SIZE = 1024 // server files blackboard code form week 3 spring term//
        if (f == null) return null
        if (!f.isFile) {
            println("<getFile> WARNING: file not found: " + f.absolutePath)
            return null
        } else {
            println("<getFile> OK: " + f.absolutePath)
            println("<getFile> file len: " + f.length())
        }
        val len = f.length()
        val fileLen = len.toInt()
        //TODO: need to fix this for large files.
        val buffer = ByteArray(fileLen)
        try {
            var b: Byte
            val iStream = FileInputStream(f)
            for (i in 0 until fileLen) {
                b = iStream.read().toByte()
                buffer[i] = b
            }
            iStream.close()
        } catch (e: IOException) {
            System.err.println("Error: $e")
            return null
        }
        return buffer
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val MAXREQ = 10
        var server: ServerSocket? = null
        var reqCount = 1
        var theFile: File? = null
        try {
            server = ServerSocket(8080)
            server.soTimeout = 30000
        } catch (e: IOException) {
            System.err.println("Cannot create socket on port 8080.")
            System.exit(1)
        }
        println("Server started. Listening on port 8080...\n")
        while (reqCount < MAXREQ) {
            var connection: Socket? = null
            connection = try {
                server!!.accept()
            } catch (e: SocketTimeoutException) {
                System.err.println("Server timeout: $e")
                break
            } catch (e: IOException) {
                System.err.println("Client accept failed: $e")
                continue
            }
            try {
                val out = PrintWriter(connection.getOutputStream(), true)
                val outB = DataOutputStream(connection.getOutputStream())
                val `in` = BufferedReader(
                    InputStreamReader(
                        connection.getInputStream()
                    )
                )
                var inputLine: String
                var doGet = false
                println("*** Client request:")
                while (`in`.readLine().also { inputLine = it } != null) {
                    println(inputLine)
                    if (inputLine.indexOf("GET") != -1) {
                        doGet = true
                        val fields = inputLine.split(" ").toTypedArray()
                        var filename = fields[1].substring(1)
                        if (filename.length == 0) filename = "index.html"
                        println(">>> GET: $filename")
                        theFile = File(RELPATH + File.separator + filename)
                        if (!theFile.isFile) {
                            println(
                                "WARNING: file not found error: "
                                        + theFile.absolutePath
                            )
                            theFile = null
                        } else {
                            println("... will GET file: " + theFile.absolutePath)
                        }
                    }
                    if (inputLine.length == 0) break
                }
                println("*** Server reply:")
                // send header (for both HEAD and GET queries)
                if (theFile != null) {
                    val data = getFile(theFile)
                    println("\tFile: " + theFile.name)
                    println("\tData length: " + data!!.size + " bytes")
                    outB.write(data)
                    println("\tData sent")
                } else {
                    val data = """<html>
<head><title> SimpleHTTPServer 2.0</title></head>
<body>
<h2>SimpleHTTPServer 2.0: hello world!<br>Received requests: $reqCount.<br><${5 - reqCount - 1}> requests to quit: reload the page.<br><a href="http://www.google.com"><img src="moon0.jpg" alt="Image file not found!">  <br></h2>
</body></html>
"""
                    out.println("HTTP/1.0 200 ok")
                    out.println("Date: " + Date())
                    out.println("Server: Simple java web server/1.0")
                    out.println("Last-Modified: " + Date())
                    if (doGet) {
                        out.println("Content-Length: " + data.length)
                    }
                    out.println("Content-Type: text/html")
                    out.println()
                    println("\tHeader sent")
                    if (doGet) { // only if received a GET query
                        out.println(data)
                        println("\tData sent")
                    }
                    println()
                }
                out.close()
                outB.close()
                `in`.close()
                connection.close()
            } catch (ioe: IOException) {
                System.err.println("I/O error: $ioe")
            }
            reqCount++
        }
        try {
            server!!.close()
        } catch (e: IOException) {
            System.err.println("Closing server socket failed: $e")
        }
        println("QUIT.")
    }
}