package com.example.cargame

import android.graphics.Bitmap
import android.graphics.Canvas
import com.example.cargame.GameView

class background(private val image: Bitmap) {
    private var x = 0
    private val y = 0
    private val dx: Int
    fun update() {
        x += dx
        if (x < -GameView.WIDTH) {
            x = 0
        }
    }

    fun draw(canvas: Canvas) {
        canvas.drawBitmap(image, x.toFloat(), y.toFloat(), null)
        if (x < 0) {
            canvas.drawBitmap(image, (x + GameView.WIDTH).toFloat(), y.toFloat(), null)
        }
    }

    init {
        dx = GameView.MOVESPEED
    }
}