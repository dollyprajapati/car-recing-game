package com.example.cargame

import com.example.cargame.car.setFrames
import com.example.cargame.car.setDelay
import com.example.cargame.car.update
import com.example.cargame.car.image
import android.graphics.Bitmap
import android.graphics.Canvas
import com.example.cargame.GameObject
import com.example.cargame.car
import com.example.cargame.GameView

class Player(res: Bitmap, w: Int, h: Int, numFrames: Int) : GameObject() {
    private val spritesheet: Bitmap
    var score: Int
        private set
    private var dya // would provide acceleration for the car //
            = 0.0
    private var up = false
    var playing = false
    private val animation = car()
    private var startTime: Long
    fun setUp(b: Boolean) {
        up = b
    }

    fun update() {
        val elapsed =
            (System.nanoTime() - startTime) / 100000 // scores goes up by this value if the car does not crash //
        if (elapsed > 50) {
            score++
            startTime = System.nanoTime()
        }
        animation.update()
        if (up) {
            dy = 1.5.let { dya -= it; dya }.toInt()
        } else {
            dy = 1.5.let { dya += it; dya }.toInt()
        }
        if (dy > 14) dy = 12
        if (dy < -14) dy = -12
        y += dy * 3
        dy = 0
    }

    fun dodraw(canvas: Canvas) {
        canvas.drawBitmap(animation.image, x, y, null)
    }

    fun resetDYA() {
        dya = 0.0
    }

    fun resetScore() {
        score = 0
    }

    init {
        x = 100
        y = GameView.HEIGHT / 2
        dy = 0
        score = 0
        height = h
        width = w
        val image = arrayOfNulls<Bitmap>(numFrames)
        spritesheet = res
        for (i in image.indices) {
            image[i] = Bitmap.createBitmap(spritesheet, i * width, 0, width, height)
        }
        animation.setFrames(image)
        animation.setDelay(15)
        startTime = System.nanoTime()
    }
}