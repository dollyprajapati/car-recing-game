package com.example.cargame

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.example.cargame.GameObject

class Smokepuff(x: Int, y: Int) : GameObject() {
    // extends the game object which will leave a trail of smoke behind the car//
    var r = 3
    fun update() {
        x -= 8
    }

    fun dodraw(canvas: Canvas) {
        val paint = Paint()
        paint.color = Color.BLACK // colour of the smoke puff//
        paint.style = Paint.Style.FILL
        canvas.drawCircle((x - r).toFloat(), (y - r).toFloat(), r.toFloat(), paint)
        canvas.drawCircle((x - r + 3).toFloat(), (y - r - 2).toFloat(), r.toFloat(), paint)
        canvas.drawCircle((x - r + 2).toFloat(), (y - r + 2).toFloat(), r.toFloat(), paint)
    }

    init {
        // defining the radius of the smoke puff//
        super.x = x
        super.y = y
    }
}