package com.example.cargame

import android.graphics.Rect

abstract class GameObject {
    var x = 0
    var y = 0
    protected var dy = 0
    protected var dx = 0
    open var width = 0
        protected set
    var height = 0
        protected set
    val rectangle: Rect
        get() = Rect(x, y, x + width, y + height)
}