package com.example.cargame

import android.content.Context
import com.example.cargame.GameThread.isRunning
import com.example.cargame.GameThread.cleanup
import com.example.cargame.GameThread.onTouch
import com.example.cargame.GameThread.pause
import com.example.cargame.background.update
import com.example.cargame.Smokepuff.update
import com.example.cargame.GameObject.rectangle
import com.example.cargame.background.draw
import com.example.cargame.Smokepuff.dodraw
import com.example.cargame.GameThread.setSurfaceSize
import com.example.cargame.GameThread.onSensorChanged
import android.view.SurfaceView
import android.view.SurfaceHolder
import android.hardware.SensorEventListener
import kotlin.jvm.Volatile
import com.example.cargame.GameThread
import com.example.cargame.background
import com.example.cargame.Player
import com.example.cargame.Smokepuff
import com.example.cargame.Obstacle
import android.widget.TextView
import android.view.View.OnTouchListener
import android.view.MotionEvent
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import android.hardware.Sensor
import com.example.cargame.R
import com.example.cargame.TheGame
import com.example.cargame.GameView
import com.example.cargame.GameObject
import android.hardware.SensorManager
import android.hardware.SensorEvent
import android.os.Handler
import android.os.Message
import android.util.AttributeSet
import java.util.*

class GameView(context: Context?, attrs: AttributeSet?) : SurfaceView(context, attrs),
    SurfaceHolder.Callback, SensorEventListener {
    @Volatile
    private var thread: GameThread? = null
    private var smokeStartTime: Long = 0
    private var ObstacleStartTime: Long = 0
    private var mHandler: Handler
    private var bg: background? = null
    private var player: Player? = null

    /* stores the smoke trails behind the cars in an array list
     *  */
    private var smoke: ArrayList<Smokepuff>? = null
    private var obstacles: ArrayList<Obstacle>? = null
    private val rand = Random()

    //Pointers to the views
    var scoreView: TextView? = null
    var statusView: TextView? = null
    var accelerometer: Sensor? = null
    var magnetometer: Sensor? = null

    //Used to release any resources.
    fun cleanup() {
        thread!!.isRunning = false
        thread!!.cleanup()
        removeCallbacks(thread)
        thread = null
        setOnTouchListener(null)
        val holder = holder
        holder.removeCallback(this)
    }

    /*
     * Setters and Getters
     */
    fun setThread(newThread: GameThread?) {
        thread = newThread
        setOnTouchListener { v, event -> thread != null && thread!!.onTouch(event) }
        isClickable = true
        isFocusable = true
    }

    fun getThread(): GameThread? {
        return thread
    }

    fun getmHandler(): Handler {
        return mHandler
    }

    fun setmHandler(mHandler: Handler) {
        this.mHandler = mHandler
    }

    /*
     * Screen functions
     */
    //ensure that we go into pause state if we go out of focus
    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        if (thread != null) {
            if (!hasWindowFocus) thread!!.pause()
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {

        //bg = new background (BitmapFactory.decodeResource(getResources(), R.drawable.bkg));//
        bg = background(BitmapFactory.decodeResource(resources, R.drawable.bkg))
        player = Player(
            BitmapFactory.decodeResource(resources, R.drawable.car1),
            65,
            25,
            1
        ) // instantiting the player//
        smoke = ArrayList()
        obstacles = ArrayList()
        smokeStartTime = System.nanoTime()
        ObstacleStartTime = System.nanoTime()
        if (thread != null) {
            thread!!.isRunning = true
            if (thread!!.state == Thread.State.NEW) {
                //Just start the new thread
                thread!!.start()
            } else {
                if (thread!!.state == Thread.State.TERMINATED) {
                    //Start a new thread
                    //Should be this to update screen with old game: new GameThread(this, thread);
                    //The method should set all fields in new thread to the value of old thread's fields 
                    thread = TheGame(this)
                    thread.isRunning = true
                    thread.start()
                }
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            if (!player!!.playing) {
                player!!.playing = true
            } else {
                player!!.setUp(true)
            }
            return true
        }
        if (event.action == MotionEvent.ACTION_UP) {
            player!!.setUp(false)
            return true
        }
        return super.onTouchEvent(event)
    }

    fun update() // so the smoke follows the direction of the car and increases in density as the the speed of the car increases//
    {
        if (player!!.playing) {
            bg!!.update()
            player!!.update()
            val missileElapsed = (System.nanoTime() - ObstacleStartTime) / 10000000
            if (missileElapsed > 2000 - player!!.score / 4) {
                println("creating obstacles")
                //the obstacles will start form the middle of the road//
                if (obstacles!!.size == 0) {
                    obstacles!!.add(
                        Obstacle(
                            BitmapFactory.decodeResource(
                                resources,
                                R.drawable.obstacle
                            ), WIDTH + 10, HEIGHT / 2, 45, 15, player!!.score, 13
                        )
                    )
                } else {
                    obstacles!!.add(
                        Obstacle(
                            BitmapFactory.decodeResource(resources, R.drawable.obstacle),
                            WIDTH + 12,
                            (rand.nextDouble() * HEIGHT).toInt(),
                            30,
                            12,
                            player!!.score,
                            10
                        )
                    )
                }

                //reset timer
                ObstacleStartTime = System.nanoTime()
            }
            //loop through every missile and check collision and remove
            for (i in obstacles!!.indices) {
                //updates the obstacles every time the car hits the obstacle//
                obstacles!![i].update()
                if (collision(obstacles!![i], player)) {
                    obstacles!!.removeAt(i)
                    player!!.playing = false
                    break
                }
                //removes the obstacles at the end of the screen//
                if (obstacles!![i].getX() < -100) {
                    obstacles!!.removeAt(i)
                    break
                }
            }
            val elapsed = (System.nanoTime() - smokeStartTime) / 10000000
            if (elapsed > 120) {
                smoke!!.add(Smokepuff(player.getX(), player.getY() + 6))
                smokeStartTime = System.nanoTime()
            }
            for (i in smoke!!.indices)  // remove the smoke after the car has gone forward//
            {
                smoke!![i].update()
                if (smoke!![i].getX() < -25) {
                    smoke!!.removeAt(i)
                }
            }
        }
    }

    fun collision(a: GameObject, b: GameObject?): Boolean {
        return if (Rect.intersects(a.rectangle, b!!.rectangle)) {
            true
        } else false
    }

    fun dodraw(canvas: Canvas?) {
        val scaleFactorX = width / (WIDTH * 1f)
        val scaleFactorY = height / (HEIGHT * 1f)
        if (canvas != null) {
            val savedState = canvas.save()
            canvas.scale(scaleFactorX, scaleFactorY)
            bg!!.draw(canvas)
            player!!.dodraw(canvas)
            for (sp in smoke!!) {
                sp.dodraw(canvas)
            }
            for (o in obstacles!!) {
                o.dodraw(canvas)
            }
            canvas.restoreToCount(savedState)
        }
    }

    //This is run whenever the phone is touched by the user
    //Always called once after surfaceCreated. Tell the GameThread the actual size
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (thread != null) {
            thread!!.setSurfaceSize(width, height)
        }
    }

    /*
     * Need to stop the GameThread if the surface is destroyed
     * Remember this doesn't need to happen when app is paused on even stopped.
     */
    override fun surfaceDestroyed(arg0: SurfaceHolder) {
        var retry = true
        if (thread != null) {
            thread!!.isRunning = false
        }

        //join the thread with this thread
        while (retry) {
            try {
                if (thread != null) {
                    thread!!.join()
                }
                retry = false
            } catch (e: InterruptedException) {
                //naugthy, ought to do something...
            }
        }
    }

    /*
     * Accelerometer
     */
    fun startSensor(sm: SensorManager) {
        accelerometer = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        magnetometer = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        sm.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
        sm.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI)
    }

    fun removeSensor(sm: SensorManager) {
        sm.unregisterListener(this)
        accelerometer = null
        magnetometer = null
    }

    //A sensor has changed, let the thread take care of it
    override fun onSensorChanged(event: SensorEvent) {
        if (thread != null) {
            thread!!.onSensorChanged(event)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}

    companion object {
        //private SensorEventListener sensorAccelerometer;
        //Handle communication from the GameThread to the View/Activity Thread
        const val WIDTH = 320
        const val HEIGHT = 480
        const val MOVESPEED = -5
    }

    init {

        //Get the holder of the screen and register interest
        val holder = holder
        holder.addCallback(this)

        //Set up a handler for messages from GameThread
        mHandler = object : Handler() {
            override fun handleMessage(m: Message) {
                if (m.data.getBoolean("score")) {
                    scoreView!!.text = m.data.getString("text")
                } else {
                    //So it is a status
                    val i = m.data.getInt("viz")
                    when (i) {
                        VISIBLE -> statusView!!.visibility = VISIBLE
                        INVISIBLE -> statusView!!.visibility = INVISIBLE
                        GONE -> statusView!!.visibility = GONE
                    }
                    statusView!!.text = m.data.getString("text")
                }
            }
        }
    }
}