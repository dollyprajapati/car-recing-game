package com.example.cargame

import android.app.Activity
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.TextView


class MultiThreading : Activity() {
    var hand = Handler()
    var STARTRACE: Button? = null
    var timer: TextView? = null

    // this class creates a loop for the startrace button mentioned in the main activity xml file , the time is reduced by 1 millisecond if the timer text is not 0;
    var run = Runnable { updateTime() }
    fun updateTime() {
        timer!!.text = "" + (timer!!.text.toString().toInt() - 1)
        if (timer!!.text.toString().toInt() == 0) {
            STARTRACE!!.visibility = View.VISIBLE
        } else {
            hand.postDelayed(run, 1000)
        }
    }
}




