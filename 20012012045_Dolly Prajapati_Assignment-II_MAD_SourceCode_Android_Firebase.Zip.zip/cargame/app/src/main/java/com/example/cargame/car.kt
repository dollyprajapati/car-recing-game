package com.example.cargame

import android.graphics.Bitmap

class car {
    private var frames: Array<Bitmap>
    var frame = 0
    private var startTime: Long = 0
    private var delay: Long = 0
    private var playedOnce = false
    fun setFrames(frames: Array<Bitmap>) {
        this.frames = frames // setting the number of frames for the user to move //
        frame = 0
        startTime = System.nanoTime()
    }

    fun setDelay(d: Long) {
        delay = d
    }

    fun update() {
        val elapsed = (System.nanoTime() - startTime) / 100000
        if (elapsed > delay) {
            frame++
            startTime = System.nanoTime()
        }
        if (frame == frames.size) {
            frame = 0
            playedOnce = true
        }
    }

    val image: Bitmap
        get() = frames[frame]

    fun playedOnce(): Boolean {
        return playedOnce
    }
}