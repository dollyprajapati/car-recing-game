package com.example.cargame

import android.content.Context
import com.example.cargame.GameView
import android.view.SurfaceHolder
import android.graphics.Bitmap
import com.example.cargame.GameThread
import android.view.MotionEvent
import android.hardware.SensorEvent
import android.hardware.SensorManager
import android.os.Bundle
import com.example.cargame.R
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.hardware.Sensor
import android.os.Handler
import android.view.View

abstract class GameThread(gameView: GameView) : Thread() {
    //Control variable for the mode of the game (e.g. STATE_WIN)
    var mode = 1

    //Control of the actual running inside run()
    var isRunning = false

    //The surface this thread (and only this thread) writes upon
    private var mSurfaceHolder: SurfaceHolder?

    //the message handler to the View/Activity thread
    private var mHandler: Handler?

    //Android Context - this stores almost all we need to know
    private var mContext: Context?

    //The view
    var mGameView: GameView?

    //We might want to extend this call - therefore protected
    protected var mCanvasWidth = 1
    protected var mCanvasHeight = 1

    //Last time we updated the game physics
    protected var mLastTime: Long = 0
    protected var mBackgroundImage: Bitmap?
    protected var score: Long = 0

    //Used for time keeping
    private var now: Long = 0
    private var elapsed = 0f

    //Rotation vectors used to calculate orientation
    var mGravity: FloatArray?
    var mGeomagnetic: FloatArray?

    /*
     * Called when app is destroyed, so not really that important here
     * But if (later) the game involves more thread, we might need to stop a thread, and then we would need this
     * Dare I say memory leak...
     */
    fun cleanup() {
        mContext = null
        mGameView = null
        mHandler = null
        mSurfaceHolder = null
    }

    //Pre-begin a game
    abstract fun setupBeginning()

    //Starting up the game
    fun doStart() {
        synchronized(monitor) {
            setupBeginning()
            mLastTime = System.currentTimeMillis() + 100
            setState(STATE_RUNNING)
            setScore(0)
        }
    }

    //The thread start
    override fun run() {
        var canvasRun: Canvas?
        while (isRunning) {
            canvasRun = null
            try {
                canvasRun = mSurfaceHolder!!.lockCanvas(null)
                synchronized(monitor) {
                    if (mode == STATE_RUNNING) {
                        updatePhysics()
                    }
                    doDraw(canvasRun)
                }
            } finally {
                if (canvasRun != null) {
                    if (mSurfaceHolder != null) mSurfaceHolder!!.unlockCanvasAndPost(canvasRun)
                }
            }
        }
    }

    /*
     * Surfaces and drawing
     */
    fun setSurfaceSize(width: Int, height: Int) {
        synchronized(monitor) {
            mCanvasWidth = width
            mCanvasHeight = height

            // don't forget to resize the background image
            mBackgroundImage = Bitmap.createScaledBitmap(mBackgroundImage!!, width, height, true)
        }
    }

    protected fun doDraw(canvas: Canvas?) {
        if (canvas == null) return
        if (mBackgroundImage != null) canvas.drawBitmap(mBackgroundImage!!, 0f, 0f, null)
    }

    private fun updatePhysics() {
        now = System.currentTimeMillis()
        elapsed = (now - mLastTime) / 1000.0f
        updateGame(elapsed)
        mLastTime = now
    }

    protected abstract fun updateGame(secondsElapsed: Float)

    /*
     * Control functions
     */
    //Finger touches the screen
    fun onTouch(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_DOWN) return false
        if (mode == STATE_READY || mode == STATE_LOSE || mode == STATE_WIN) {
            doStart()
            return true
        }
        if (mode == STATE_PAUSE) {
            unpause()
            return true
        }
        synchronized(monitor) { actionOnTouch(e.rawX, e.rawY) }
        return false
    }

    protected open fun actionOnTouch(x: Float, y: Float) {
        //Override to do something
    }

    //The Orientation has changed
    fun onSensorChanged(event: SensorEvent) {
        synchronized(monitor) {
            if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) mGravity = event.values
            if (event.sensor.type == Sensor.TYPE_MAGNETIC_FIELD) mGeomagnetic = event.values
            if (mGravity != null && mGeomagnetic != null) {
                val R = FloatArray(9)
                val I = FloatArray(9)
                val success = SensorManager.getRotationMatrix(R, I, mGravity, mGeomagnetic)
                if (success) {
                    val orientation = FloatArray(3)
                    SensorManager.getOrientation(R, orientation)
                    actionWhenPhoneMoved(orientation[2], orientation[1], orientation[0])
                }
            }
        }
    }

    protected open fun actionWhenPhoneMoved(
        xDirection: Float,
        yDirection: Float,
        zDirection: Float
    ) {
        //Override to do something
    }

    /*
     * Game states
     */
    fun pause() {
        synchronized(monitor) { if (mode == STATE_RUNNING) setState(STATE_PAUSE) }
    }

    fun unpause() {
        // Move the real time clock up to now
        synchronized(monitor) { mLastTime = System.currentTimeMillis() }
        setState(STATE_RUNNING)
    }

    //Send messages to View/Activity thread
    fun setState(mode: Int) {
        synchronized(monitor) { setState(mode, null) }
    }

    fun setState(mode: Int, message: CharSequence?) {
        synchronized(monitor) {
            this.mode = mode
            if (this.mode == STATE_RUNNING) {
                val msg = mHandler!!.obtainMessage()
                val b = Bundle()
                b.putString("text", "")
                b.putInt("viz", View.INVISIBLE)
                b.putBoolean("showAd", false)
                msg.data = b
                mHandler!!.sendMessage(msg)
            } else {
                val msg = mHandler!!.obtainMessage()
                val b = Bundle()
                val res = mContext!!.resources
                var str: CharSequence = ""
                if (this.mode == STATE_READY) str =
                    res.getText(R.string.mode_ready) else if (this.mode == STATE_PAUSE) str =
                    res.getText(R.string.mode_pause) else if (this.mode == STATE_LOSE) str =
                    res.getText(R.string.mode_lose) else if (this.mode == STATE_WIN) {
                    str = res.getText(R.string.mode_win)
                }
                if (message != null) {
                    str = """
                    $message
                    $str
                    """.trimIndent()
                }
                b.putString("text", str.toString())
                b.putInt("viz", View.VISIBLE)
                msg.data = b
                mHandler!!.sendMessage(msg)
            }
        }
    }

    /*
     * Getter and setter
     */
    fun setSurfaceHolder(h: SurfaceHolder?) {
        mSurfaceHolder = h
    }

    /* ALL ABOUT SCORES */ //Send a score to the View to view 
    //Would it be better to do this inside this thread writing it manually on the screen?
    fun setScore(score: Long) {
        this.score = score
        synchronized(monitor) {
            val msg = mHandler!!.obtainMessage()
            val b = Bundle()
            b.putBoolean("score", true)
            b.putString("text", scoreString.toString())
            msg.data = b
            mHandler!!.sendMessage(msg)
        }
    }

    fun getScore(): Float {
        return score.toFloat()
    }

    fun updateScore(score: Long) {
        setScore(this.score + score)
    }

    protected val scoreString: CharSequence
        protected get() = java.lang.Long.toString(Math.round(score.toFloat()).toLong())

    companion object {
        //Different mMode states
        const val STATE_LOSE = 1
        const val STATE_PAUSE = 2
        const val STATE_READY = 3
        const val STATE_RUNNING = 4
        const val STATE_WIN = 5

        //Used to ensure appropriate threading
        const val monitor = 1
    }

    init {
        mGameView = gameView
        mSurfaceHolder = gameView.holder
        mHandler = gameView.getmHandler()
        mContext = gameView.context
        mBackgroundImage = BitmapFactory.decodeResource(
            gameView.context.resources,
            R.drawable.bkg
        )
    }
}