package com.example.cargame

import com.example.cargame.car.setFrames
import com.example.cargame.car.setDelay
import com.example.cargame.car.update
import com.example.cargame.car.image
import android.graphics.Bitmap
import android.graphics.Canvas
import com.example.cargame.GameObject
import com.example.cargame.car
import java.lang.Exception
import java.util.*

abstract class Obstacle(res: Bitmap, x: Int, y: Int, w: Int, h: Int, s: Int, numFrames: Int) :
    GameObject() {
    private val score: Int
    private var speed: Int
    private val rand = Random()
    private val animation = car()
    private val spritesheet: Bitmap
    override var width = 0
        get() = field - 15
        private set

    fun update() {
        x -= speed
        animation.update()
    }

    fun dodraw(canvas: Canvas) {
        try {
            canvas.drawBitmap(animation.image, x, y, null)
        } catch (e: Exception) {
        }
    }

    init {
        super.x = x
        super.y = y
        score = s
        speed = 12 + (rand.nextDouble() * score / 15).toInt()

        //will limit the speed of the obstacle
        if (speed > 25) speed = 40
        val image = arrayOfNulls<Bitmap>(numFrames)
        spritesheet = res
        for (i in image.indices) {
            image[i] = Bitmap.createBitmap(spritesheet, 0, i * h, w, h)
        }
        animation.setFrames(image)
        animation.setDelay((50 - speed).toLong())
    }
}